﻿using System;

namespace PersonsInfo
{
    public class StartUp
    {
        static void Main(string[] args)
        {

        }
    }
}
