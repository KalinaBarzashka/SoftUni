﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AquaShop.Models.Decoration
{
    public class Plant : Decoration
    {
        public Plant() : base(5, 10)
        {
        }
    }
}